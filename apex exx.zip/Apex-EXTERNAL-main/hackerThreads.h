//
// Created by Administrator on 2019/6/20.
//

#ifndef CATAPEXCPP_HACKERTHREADS_H
#define CATAPEXCPP_HACKERTHREADS_H

#endif //CATAPEXCPP_HACKERTHREADS_H

DWORD WINAPI InfoThread(LPVOID lpParam);
DWORD WINAPI EntityManager(LPVOID lpParam);
DWORD WINAPI SuperAim(LPVOID lpParam);
DWORD WINAPI StartDraw(LPVOID lpParam);
DWORD WINAPI HentaiThread(LPVOID lpParam);

DWORD WINAPI ZiDongGuaJi(LPVOID lpParam);


