//
// Created by Administrator on 2021/6/0.
//

#ifndef CATAPEXCPP_DRAWCALLBACK_H
#define CATAPEXCPP_DRAWCALLBACK_H

#endif //CATAPEXCPP_DRAWCALLBACK_H
#define myFontSize			16  //�����С
void draw();